
(function(compId){var _=null,y=true,n=false,x37='19px',e59='${Rectangle5}',x54='rgb(0, 0, 0)',e13='${video}',e45='${t12}',e18='${Rectangle13}',x22='143px',x38='344px',x8='rgba(255,255,255,1.00)',x47='430px',x32='244px',x63='rgba(192,192,192,1)',x3='6.0.0.400',x65='Rectangle2',x60='Rectangle4',lf='left',x62='980px',e55='${Rectangle6}',x30='96px',x50='252px',x21='113px',e51='${Rectangle}',x24='auto',x20='107px',x12='rgba(255,255,255,1)',tp='top',xc='rgba(0,0,0,1)',x23='154px',x42='400px',x1='6.0.0',rz='rotateZ',x58='Rectangle5',x2='5.0.0',x9='rgba(192,192,192,0)',x4='rgba(0,0,0,0)',x46='Rectangle',zx='scaleX',x49='rgba(192,192,192,0.00)',x53='Rectangle6',x26='0',e17='${Rectangle10}',x56='2px',x11='solid',m='rect',x28='0px',h='height',x64='983px',e61='${Rectangle4}',x57='241px',o='opacity',x39='abc',x52='5px',bg='background-color',x34='t22',zy='scaleY',x33='1.6',bc='border-color',d='display',x10='rgba(255,255,255,0)',g='image',b='block',e44='${t22}',e43='${abc}',e19='${Symbol_1}',e14='${xem_ngay}',x41='550px',w='width',i='none',e16='${bg1}',x48='250px',x36='80px',x29='424px',e15='${bg2}',x31='220px',x25='t12';var g40='abc.png',g5='bg1.jpg',g7='xem%20ngay.png',g35='t2.png',g6='bg2.jpg',g27='t1.png';var im='images/',aud='media/',vid='media/',js='js/',fonts={},opts={'gAudioPreloadPreference':'auto','gVideoPreloadPreference':'auto'},resources=[],scripts=[],symbols={"stage":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{id:'bg1',t:g,r:['0px','0px','980px','250px','auto','auto'],o:'0',f:[x4,im+g5,'0px','0px']},{id:'bg2',t:g,r:['-1px','0px','980px','250px','auto','auto'],o:'0',f:[x4,im+g6,'0px','0px']},{id:'xem_ngay',t:g,r:['713px','181px','199px','56px','auto','auto'],o:'0',f:[x4,im+g7,'0px','0px'],tf:[[],[],[],['0.5','0.5']]},{id:'Symbol_1',symbolName:'Symbol_1',t:m,r:['425px','9px','550','400','auto','auto'],o:'1',tf:[[],[],[],['0.3','0.3']]},{id:'Rectangle10',v:i,t:m,r:['0px','0px','436px','250px','auto','auto'],f:[x8],s:[0,"rgb(0, 0, 0)",i]},{id:'video',v:i,t:m,r:['1px','2px','436px','245px','auto','auto'],f:[x9],s:[0,"rgb(0, 0, 0)",i]},{id:'Rectangle13',t:m,r:['-3px','0px','979px','248px','auto','auto'],f:[x10],s:[1,"rgba(18,18,18,1.00)",x11]}],style:{'${Stage}':{isStage:true,r:['null','null','980px','250px','auto','auto'],overflow:'hidden',f:[x12]}}},tt:{d:6290,a:y,data:[["eid106",lf,5165,0,"swing",e13,'1px','1px'],["eid14",zy,5040,460,"swing",e14,'0.5','1'],["eid6",o,4175,865,"swing",e15,'0','1'],["eid114",lf,5550,0,"linear",e16,'0px','0px'],["eid78",d,0,0,"swing",e17,i,i],["eid79",d,5165,0,"swing",e17,i,b],["eid85",w,5165,0,"swing",e13,'436px','436px'],["eid65",d,0,0,"swing",e13,i,i],["eid66",d,5165,0,"swing",e13,i,b],["eid100",h,5165,0,"swing",e18,'248px','248px'],["eid119",lf,5550,0,"linear",e18,'-3px','-3px'],["eid15",o,5040,460,"swing",e14,'0','1'],["eid27",lf,5165,1085,"swing",e19,'425px','575px'],["eid86",h,5165,0,"swing",e13,'245px','245px'],["eid129",w,0,0,"swing",e18,'979px','979px'],["eid125",w,5165,60,"swing",e18,'979px','978px'],["eid3",o,0,1500,"linear",e16,'0','1'],["eid124",lf,5500,0,"swing",e14,'713px','713px'],["eid81",w,5165,0,"swing",e17,'436px','436px'],["eid24",zy,5165,0,"swing",e19,'0.3','0.3'],["eid18",d,5165,0,"linear",e19,i,b],["eid102",tp,5165,0,"swing",e13,'2px','2px'],["eid23",zx,5165,0,"swing",e19,'0.3','0.3'],["eid98",bc,5165,0,"swing",e18,'rgba(18,18,18,1.00)','rgba(18,18,18,1.00)'],["eid13",zx,5040,460,"swing",e14,'0.5','1'],["eid123",lf,5165,385,"linear",e15,'-1px','0px'],["eid22","tr",5125,function(e,d){this.eSA(e,d);},['play','${Symbol_1}',[]]]]}},"Symbol_1":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x20,x21,x22,x23,x24,x24],id:x25,o:x26,t:g,f:[x4,im+g27,x28,x28]},{r:[x29,x30,x31,x32,x24,x24],tf:[[],[],[],[x33,x33]],id:x34,o:x26,t:g,f:[x4,im+g35,x28,x28]},{r:[x36,x37,x38,x38,x24,x24],id:x39,t:g,f:[x4,im+g40,x28,x28]}],style:{'${symbolSelector}':{r:[_,_,x41,x42]}}},tt:{d:1165,a:n,data:[["eid338",rz,60,215,"linear",e43,'-62deg','0deg'],["eid339",rz,275,515,"linear",e43,'0deg','73deg'],["eid340",rz,790,375,"linear",e43,'73deg','100deg'],["eid115",lf,145,290,"linear",e44,'124px','314px'],["eid128",lf,435,380,"linear",e44,'314px','424px'],["eid118",zx,145,290,"linear",e44,'1.5','1.88'],["eid126",zx,435,380,"linear",e44,'1.88','1.6'],["eid120",zy,145,290,"linear",e44,'1.5','1.88'],["eid127",zy,435,380,"linear",e44,'1.88','1.6'],["eid333",o,60,215,"linear",e43,'0','1'],["eid334",o,790,375,"linear",e43,'1','0'],["eid330",zx,60,215,"linear",e43,'0.47','1'],["eid331",zx,275,515,"linear",e43,'1','1.22'],["eid332",zx,790,375,"linear",e43,'1.22','1.42'],["eid133",lf,60,410,"linear",e45,'259px','107px'],["eid139",lf,470,405,"linear",e45,'107px','87px'],["eid117",o,145,290,"linear",e44,'0','1'],["eid343",o,435,380,"linear",e44,'1','0.26016260162602'],["eid134",o,60,410,"linear",e45,'0','1'],["eid140",o,470,405,"linear",e45,'1','0'],["eid116",tp,145,0,"linear",e44,'96px','96px'],["eid335",zy,60,215,"linear",e43,'0.47','1'],["eid336",zy,275,515,"linear",e43,'1','1.22'],["eid337",zy,790,375,"linear",e43,'1.22','1.42']]}},"video":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:m,id:x46,s:[0,xc,i],r:[x28,x28,x47,x48,x24,x24],f:[x49]}],style:{'${symbolSelector}':{r:[_,_,x47,x50]}}},tt:{d:6250,a:y,data:[["eid29",bg,6250,0,"linear",e51,'rgba(192,192,192,0.00)','rgba(192,192,192,0.00)'],["eid62",h,5446,0,"swing",e51,'250px','250px'],["eid64",w,5446,0,"swing",e51,'430px','430px']]}},"Symbol_2":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:m,r:[x28,x28,x47,x52,x24,x24],id:x53,s:[0,x54,i],v:i,f:[x12]}],style:{'${symbolSelector}':{r:[_,_,x47,x52]}}},tt:{d:5165,a:y,data:[["eid70",d,0,0,"swing",e55,i,i],["eid73",d,5165,0,"swing",e55,i,b]]}},"Symbol_3":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:m,r:[x28,x52,x56,x57,x24,x24],id:x58,s:[0,x54,i],v:i,f:[x12]}],style:{'${symbolSelector}':{r:[_,_,x28,x28]}}},tt:{d:5165,a:y,data:[["eid71",d,0,0,"swing",e59,i,i],["eid75",d,5165,0,"swing",e59,i,b]]}},"Symbol_4":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:m,r:[x28,x28,x47,x52,x24,x24],id:x60,s:[0,x54,i],v:i,f:[x8]}],style:{'${symbolSelector}':{r:[_,_,x28,x28]}}},tt:{d:5165,a:y,data:[["eid72",d,0,0,"swing",e61,i,i],["eid74",d,5165,0,"swing",e61,i,b]]}},"Symbol_5":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x28,x28,x62,x48,x24,x24],id:x46,s:[0,xc,i],t:m,f:[x63]}],style:{'${symbolSelector}':{r:[_,_,x62,x48]}}},tt:{d:0,a:y,data:[]}},"Symbol_6":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x28,x28,x64,x48,x24,x24],id:x65,s:[0,x54,i],t:m,f:[x49]}],style:{'${symbolSelector}':{r:[_,_,x64,x48]}}},tt:{d:0,a:y,data:[]}}};AdobeEdge.registerCompositionDefn(compId,symbols,fonts,scripts,resources,opts);})("EDGE-3854608");
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;Edge.registerEventBinding(compId,function($){
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindSymbolAction(compId,symbolName,"creationComplete",function(sym,e){});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"document","compositionReady",function(sym,e){yepnope({nope:['js/YoutubeSizmek.js'],complete:init});function init(){}});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${Rectangle13}","click",function(sym,e){console.log('vào btnClick');EB.clickthrough();window.top.postMessage('admclick_mm_16931412',document.referrer);});
//Edge binding end
})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'Symbol_1'
(function(symbolName){})("Symbol_1");
//Edge symbol end:'Symbol_1'

//=========================================================

//Edge symbol: 'video'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${Rectangle}","click",function(sym,e){console.log('vào video');EB.clickthrough();window.top.postMessage('admclick_mm_16931412',document.referrer);});
//Edge binding end
})("video");
//Edge symbol end:'video'

//=========================================================

//Edge symbol: 'Symbol_2'
(function(symbolName){})("Symbol_2");
//Edge symbol end:'Symbol_2'

//=========================================================

//Edge symbol: 'Symbol_3'
(function(symbolName){})("Symbol_3");
//Edge symbol end:'Symbol_3'

//=========================================================

//Edge symbol: 'Symbol_4'
(function(symbolName){})("Symbol_4");
//Edge symbol end:'Symbol_4'

//=========================================================

//Edge symbol: 'Symbol_5'
(function(symbolName){})("Symbol_5");
//Edge symbol end:'Symbol_5'

//=========================================================

//Edge symbol: 'Symbol_6'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${Rectangle2}","click",function(sym,e){console.log('vào btnClick');EB.clickthrough();window.top.postMessage('admclick_mm_16931412',document.referrer);});
//Edge binding end
})("Symbol_6");
//Edge symbol end:'Symbol_6'
})})(AdobeEdge.$,AdobeEdge,"EDGE-3854608");